﻿using System.Windows.Controls;

namespace CourseProject.Pages
{
    /// <summary>
    ///     Логика взаимодействия для Main.xaml
    /// </summary>
    public partial class Main : UserControl
    {
        public Main()
        {
            InitializeComponent();
        }
    }
}