﻿using System.Windows.Controls;

namespace CourseProject.Pages
{
    /// <summary>
    ///     Логика взаимодействия для PointerPage.xaml
    /// </summary>
    public partial class PointerPage : UserControl
    {
        public PointerPage()
        {
            InitializeComponent();
        }
    }
}