﻿using System.Windows;

namespace CourseProject
{
    /// <summary>
    ///     Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}