﻿namespace CourseProject
{
    internal static class Parameters
    {
        public static MainWindow Mw { get; set; }
    }
}